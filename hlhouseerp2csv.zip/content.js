(function () {
    if (document.getElementById('hl-side-btn')) return;

    // ==========================================
    // 1. 建立側邊浮動 UI (小按鈕 + 展開面板)
    // ==========================================
    const sideBtn = document.createElement('div');
    sideBtn.id = 'hl-side-btn';
    sideBtn.innerHTML = "📥";
    sideBtn.style.cssText = `
        position: fixed; top: 50%; right: 0; transform: translateY(-50%);
        width: 40px; height: 50px; background: #28a745; color: white;
        border-radius: 10px 0 0 10px; display: flex; align-items: center; justify-content: center;
        cursor: pointer; font-size: 20px; box-shadow: -2px 0 5px rgba(0,0,0,0.2);
        z-index: 999999; transition: 0.2s;
    `;

    const panel = document.createElement('div');
    panel.id = 'hl-panel';
    panel.style.cssText = `
        position: fixed; top: 50%; right: 50px; transform: translateY(-50%);
        width: 220px; background: white; border: 2px solid #28a745; border-radius: 10px;
        padding: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        z-index: 999998; font-family: sans-serif; display: none; text-align: center;
    `;

    panel.innerHTML = `
        <div style="font-weight: bold; margin-bottom: 10px; color: #333;">房地產下載器</div>
        <div id="hl-progress-wrapper" style="display: none; justify-content: center; margin: 15px 0;">
            <div id="hl-circle" style="width: 80px; height: 80px; border-radius: 50%; background: conic-gradient(#eee 100%, #eee 0); display: flex; align-items: center; justify-content: center;">
                <div style="width: 65px; height: 65px; background: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 14px; color: #28a745;" id="hl-circle-text">
                    0%
                </div>
            </div>
        </div>
        <div id="hl-status" style="font-size: 12px; color: #d9534f; margin-bottom: 15px; font-weight: bold;">請在網頁上點擊一次【搜尋】來綁定條件</div>
        <button id="hl-start-btn" disabled style="
            width: 100%; padding: 10px; background: #6c757d; color: white;
            border: none; border-radius: 5px; font-weight: bold; cursor: not-allowed;
        ">等待條件中</button>
    `;

    document.body.appendChild(sideBtn);
    document.body.appendChild(panel);

    sideBtn.addEventListener('click', () => {
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    });

    // ==========================================
    // 2. 接收 Background 攔截到的封包
    // ==========================================
    let activePayload = null;
    const startBtn = document.getElementById('hl-start-btn');
    const statusText = document.getElementById('hl-status');

    chrome.runtime.onMessage.addListener((msg) => {
        if (msg.type === "NEW_PAYLOAD") {
            activePayload = msg.payload;
            statusText.style.color = "#28a745";
            statusText.innerText = "✅ 已成功攔截篩選條件！";
            startBtn.innerText = "開始下載";
            startBtn.disabled = false;
            startBtn.style.background = "#28a745";
            startBtn.style.cursor = "pointer";
        }
    });

    // ==========================================
    // 3. API 抓取邏輯 (套用攔截到的 activePayload)
    // ==========================================
    const progressWrapper = document.getElementById('hl-progress-wrapper');
    const circle = document.getElementById('hl-circle');
    const circleText = document.getElementById('hl-circle-text');

    startBtn.addEventListener('click', async () => {
        if (!activePayload) return;

        startBtn.disabled = true;
        startBtn.style.background = "#ccc";
        startBtn.innerText = "抓取中...";
        progressWrapper.style.display = "flex";
        statusText.innerText = "連線中...";

        let allData = [];
        let displayStart = 0;
        const displayLength = 100;

        // 拿出攔截到的分頁資訊底稿
        let qPageInfo = JSON.parse(activePayload.QPageInfo);

        while (true) {
            // 自動控制翻頁
            qPageInfo.find(p => p.name === "iDisplayStart").value = displayStart;
            qPageInfo.find(p => p.name === "iDisplayLength").value = displayLength;
            activePayload.QPageInfo = JSON.stringify(qPageInfo);

            try {
                const response = await fetch("/RES/EstateSystem/Market/SellingPrice_Q.aspx/ajaxDoQuery", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json; charset=UTF-8",
                        "Accept": "application/json, text/javascript, */*; q=0.01",
                        "X-Requested-With": "XMLHttpRequest"
                    },
                    body: JSON.stringify(activePayload) // 完全使用網站原本的參數
                });

                const textRes = await response.text();
                let jsonRes = JSON.parse(textRes);
                let rawData = typeof jsonRes.d === 'string' ? JSON.parse(jsonRes.d) : jsonRes.d;
                const records = rawData.data || rawData.aaData;

                if (!records || records.length === 0) break;

                allData = allData.concat(records);
                displayStart += displayLength;

                // 更新圓形進度條
                let totalRecords = rawData.recordsTotal || rawData.iTotalRecords || allData.length;
                let percent = Math.floor((allData.length / totalRecords) * 100);
                if (percent > 100) percent = 100;

                circle.style.background = `conic-gradient(#28a745 ${percent}%, #eee 0)`;
                circleText.innerText = `${percent}%`;
                statusText.innerText = `進度：${allData.length} / ${totalRecords} 筆`;

                await new Promise(r => setTimeout(r, 400));

            } catch (e) {
                console.error("API 請求錯誤:", e);
                statusText.innerText = "❌ 發生錯誤";
                break;
            }
        }

        if (allData.length > 0) {
            circleText.innerText = "完成";
            statusText.innerText = `✅ 共下載 ${allData.length} 筆`;

            const headers = ["案名", "地址", "總建坪", "地坪", "成交價(萬)", "單價(萬/坪)", "成交日期", "建築型態", "使用分區", "臨路(米)", "屋齡(年)", "登錄店家"];

            const csvContent = allData.map(row => {
                const cleanAddress = (row.ES_ESTAddressFull || "").replace(/<[^>]*>?/gm, '').trim();
                const rowData = [
                    row.ES_ESTName || "",
                    cleanAddress,
                    row.ES_ESTTLArea || "",
                    row.ES_ESTLDArea || "",
                    row.ES_ESTDealMillion || "",
                    row.ES_ESTDealUPMillion || "",
                    row.ES_ESTDealDate || "",
                    row.ES_ESTType || "",
                    row.ES_ESTAreaTypeName || "",
                    row.ES_ESTRWidth || "",
                    row.ES_ESTHouseAge || "",
                    row.ES_SIMName || ""
                ];
                return rowData.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',');
            });

            const finalCsv = "\uFEFF" + headers.join(',') + '\n' + csvContent.join('\n');
            const blob = new Blob([finalCsv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = `房地產篩選結果_${new Date().toISOString().slice(0, 10).replace(/-/g, "")}.csv`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        startBtn.innerText = "重新下載";
        startBtn.disabled = false;
        startBtn.style.background = "#28a745";
    });
})();