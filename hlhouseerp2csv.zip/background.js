chrome.webRequest.onBeforeRequest.addListener(
    (details) => {
        // 鎖定目標 API
        if (details.method === "POST" && details.url.includes("ajaxDoQuery")) {
            // 確保有 Request Body
            if (details.requestBody && details.requestBody.raw && details.requestBody.raw[0]) {
                try {
                    // 將二進位封包解碼回 JSON 字串
                    const bodyString = new TextDecoder("utf-8").decode(details.requestBody.raw[0].bytes);
                    const payload = JSON.parse(bodyString);

                    // 把攔截到的最純粹 Payload，傳給我們網頁上的 content.js
                    chrome.tabs.sendMessage(details.tabId, { type: "NEW_PAYLOAD", payload: payload }).catch(() => { });
                } catch (e) {
                    console.error("解析 Payload 失敗", e);
                }
            }
        }
    },
    { urls: ["*://*.hlhouseerp.com.tw/*", "*://hlhouseerp.com.tw/*"] },
    ["requestBody"]
);